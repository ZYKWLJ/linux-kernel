/**
 * filename:hello.c
 * description: 测试makefile
 * author:EthanYankang
 * create time:2025/05/28 18:36:13
 */
#include <stdio.h>
#include "world.c"
int main()
{
    printf("hello!\n");
    print_world();
    return 0;
}