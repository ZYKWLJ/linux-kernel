/**
* filename:world.c
* description: 
* author:EthanYankang
* create time:2025/05/28 19:04:43
*/
#include <stdio.h>
int print_world()
{
    printf("world!\n");
    return 0;
}